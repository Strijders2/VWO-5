class Raster {
  constructor(r,k) {
    this.aantalRijen = r;
    this.aantalKolommen = k;
    this.celGrootte = null;
  }
  
  berekenCelGrootte() {
    this.celGrootte = canvas.width / this.aantalKolommen;
  }
  
  teken() {
    push();
    noFill();
    stroke('grey');
    for (var rij = 0;rij < this.aantalRijen;rij++) {
      for (var kolom = 0;kolom < this.aantalKolommen;kolom++) {
        rect(kolom*this.celGrootte,rij*this.celGrootte,this.celGrootte,this.celGrootte);
      }
    }
    pop();
  }
}

class Jos {
  constructor() {
    this.x = 400;
    this.y = 300;
    this.animatie = [];
    this.frameNummer =  3;
    this.stapGrootte = null;
    this.gehaald = false;
  }
  
  beweeg() {
    if (keyIsDown(65)) {
      this.x -= this.stapGrootte;
      this.frameNummer = 2;
    }
    if (keyIsDown(68)) {
      this.x += this.stapGrootte;
      this.frameNummer = 1;
    }
    if (keyIsDown(87)) {
      this.y -= this.stapGrootte;
      this.frameNummer = 4;
    }
    if (keyIsDown(83)) {
      this.y += this.stapGrootte;
      this.frameNummer = 5;
    }
    
    this.x = constrain(this.x,0,canvas.width);
    this.y = constrain(this.y,0,canvas.height - raster.celGrootte);
    
    if (this.x == canvas.width) {
      this.gehaald = true;
    }
  }
wordtGeraakt(vijand) {
  // Bepaal de randen van de speler en de vijand (of bom)
  let marge = 10; // Marge in pixels voor detectie

  let spelerLinks = this.x + marge;
  let spelerRechts = this.x + raster.celGrootte - marge;
  let spelerBoven = this.y + marge;
  let spelerOnder = this.y + raster.celGrootte - marge;

  let vijandLinks = vijand.x + marge;
  let vijandRechts = vijand.x + raster.celGrootte - marge;
  let vijandBoven = vijand.y + marge;
  let vijandOnder = vijand.y + raster.celGrootte - marge;

  // Controleer of de randen met marge overlappen
  return !(
    spelerOnder < vijandBoven ||
    spelerBoven > vijandOnder ||
    spelerRechts < vijandLinks ||
    spelerLinks > vijandRechts
  );
}

  
  toon() {
    image(this.animatie[this.frameNummer],this.x,this.y,raster.celGrootte,raster.celGrootte);
  }
}  

class Vijand {
  constructor(x,y) {
    this.x = x;
    this.y = y;
    this.sprite = null;
    this.stapGrootte = null;
  }

  beweeg() {
    this.x += floor(random(-1,2))*this.stapGrootte;
    this.y += floor(random(-1,2))*this.stapGrootte;

    this.x = constrain(this.x,0,canvas.width - raster.celGrootte);
    this.y = constrain(this.y,0,canvas.height - raster.celGrootte);
  }
  
  toon() {
    image(this.sprite,this.x,this.y,raster.celGrootte,raster.celGrootte);
  }
}
class Bom {
  constructor(x, y) {
    this.x = x; // De x-positie van de bom, uitgelijnd op raster
    this.y = y; // De y-positie van de bom, uitgelijnd op raster
    this.sprite = loadImage("images/sprites/bom.png"); // Laadt bom-afbeelding
    this.stapGrootte = null; // Stapgrootte wordt later ingesteld
    this.beweegRichting = 1; // Richting waarin de bom beweegt
    this.snelheid = random(0.3, 0.6); // Willekeurige snelheid tussen 0.3 en 0.6
  }

  beweeg() {
    // Beweeg de bom op en neer binnen het raster met de willekeurige snelheid
    this.y += this.beweegRichting * this.stapGrootte * this.snelheid;

    // Verander de richting als de bom de rand van het raster bereikt
    if (this.y <= 0 || this.y >= canvas.height - raster.celGrootte) {
      this.beweegRichting *= -1; // Verander richting
    }
  }

  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte); // Toon de bom binnen het raster
  }
}
class appel {
 constructor() {
    this.x = floor(random(1,raster.aantalKolommen))*raster.celGrootte + 5;
    this.y = floor(random(0,raster.aantalRijen))*raster.celGrootte + 4;
  }
//de appel wordt perfect in een hokje geplaatst

  toon() {
    image(this.sprite,this.x,this.y,raster.celGrootte - 10,raster.celGrootte - 10);   
  }   // Appel die zorgt voor +1 leven na het eten.

  verplaats(){
  this.x = 900
  this.y = floor(random(0, raster.aantalRijen - 1)) * raster.celGrootte + 4;
  }
}
function preload() {
  brug = loadImage("images/backgrounds/dame_op_brug_1800.jpg");
}
function setup() {
  canvas = createCanvas(900, 600);
  canvas.parent();
  frameRate(10);
  textFont("Verdana");
  textSize(90);
  
  raster = new Raster(12, 18);  // Raster van 12 rijen en 18 kolommen
  raster.berekenCelGrootte();   // Bereken de grootte van elke cel

  eve = new Jos();  // Speler
  eve.stapGrootte = raster.celGrootte;
  for (var b = 0; b < 6; b++) {
    frameEve = loadImage("images/sprites/Eve100px/Eve_" + b + ".png");
    eve.animatie.push(frameEve);
  }

  alice = new Vijand(700, 200);
  alice.stapGrootte = eve.stapGrootte;
  alice.sprite = loadImage("images/sprites/Alice100px/Alice.png");

  bob = new Vijand(600, 400);
  bob.stapGrootte = eve.stapGrootte;
  bob.sprite = loadImage("images/sprites/Bob100px/Bob.png");
  
  // Voeg vijf bommen toe, uitgelijnd op het raster
  bommen = [];
  for (let i = 0; i < 5; i++) {
    // Willekeurige startpositie binnen het raster, rechts van het midden (kolommen > raster.aantalKolommen / 2)
    let startX = floor(random(floor(raster.aantalKolommen / 2) + 1, raster.aantalKolommen)) * raster.celGrootte;
    let startY = floor(random(0, raster.aantalRijen)) * raster.celGrootte;    // Veelvoud van raster.celGrootte
    let bom = new Bom(startX, startY);  // Geef startX en startY door aan de constructor van Bom
    bom.stapGrootte = raster.celGrootte; // Stapgrootte is gelijk aan celgrootte
    bommen.push(bom);  // Voeg de bom toe aan de lijst van bommen
  }
}
function draw() {
  background(brug);  // Achtergrondafbeelding
  raster.teken();    // Raster tekenen
  
  eve.beweeg();      // Beweging van speler
  alice.beweeg();    // Beweging van vijand Alice
  bob.beweeg();      // Beweging van vijand Bob
  
  eve.toon();        // Toon speler
  alice.toon();      // Toon Alice
  bob.toon();        // Toon Bob

  // Toon en beweeg de vijf bommen
  for (let bom of bommen) {
    bom.beweeg();    // Beweeg elke bom op en neer
    bom.toon();      // Toon elke bom
    
    // Check of de speler geraakt wordt door een van de bommen
    if (eve.wordtGeraakt(bom)) {
      noLoop();      // Stop het spel als de speler geraakt wordt
    }
  }

  // Check of de speler geraakt wordt door Alice of Bob
  if (eve.wordtGeraakt(alice) || eve.wordtGeraakt(bob)) {
    noLoop();        // Stop het spel als de speler geraakt wordt
  }

  // Check of de speler het einde heeft bereikt
  if (eve.gehaald) {
    background('green');
    fill('white');
    text("Je hebt gewonnen!", 30, 300);
    noLoop();        // Stop het spel als de speler wint
  }
}
