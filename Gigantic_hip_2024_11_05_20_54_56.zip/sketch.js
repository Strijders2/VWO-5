class Raster {
  constructor(r, k) {
    this.aantalRijen = r;
    this.aantalKolommen = k;
    this.celGrootte = null;
  }

  berekenCelGrootte() {
    this.celGrootte = canvas.width / this.aantalKolommen;
  }

  teken() {
    push();
    noFill();
    stroke('grey');
    for (var rij = 0; rij < this.aantalRijen; rij++) {
      for (var kolom = 0; kolom < this.aantalKolommen; kolom++) {
        rect(kolom * this.celGrootte, rij * this.celGrootte, this.celGrootte, this.celGrootte);
      }
    }
    pop();
  }
}

class Jos {
  constructor() {
    this.x = 400;
    this.y = 300;
    this.animatie = [];
    this.frameNummer = 3;
    this.stapGrootte = null;
    this.gehaald = false;
    this.leven = 1; // Start met 1 leven
    this.startX = this.x; // Sla de startpositie op
    this.startY = this.y; // Sla de startpositie op
  }

  beweeg() {
    if (keyIsDown(65)) {
      this.x -= this.stapGrootte;
      this.frameNummer = 2;
    }
    if (keyIsDown(68)) {
      this.x += this.stapGrootte;
      this.frameNummer = 1;
    }
    if (keyIsDown(87)) {
      this.y -= this.stapGrootte;
      this.frameNummer = 4;
    }
    if (keyIsDown(83)) {
      this.y += this.stapGrootte;
      this.frameNummer = 5;
    }

    this.x = constrain(this.x, 0, canvas.width);
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);

    if (this.x == canvas.width) {
      this.gehaald = true;
    }
  }

  wordtGeraakt(vijand) {
    let marge = 10;

    let spelerLinks = this.x + marge;
    let spelerRechts = this.x + raster.celGrootte - marge;
    let spelerBoven = this.y + marge;
    let spelerOnder = this.y + raster.celGrootte - marge;

    let vijandLinks = vijand.x + marge;
    let vijandRechts = vijand.x + raster.celGrootte - marge;
    let vijandBoven = vijand.y + marge;
    let vijandOnder = vijand.y + raster.celGrootte - marge;

    return !(
      spelerOnder < vijandBoven ||
      spelerBoven > vijandOnder ||
      spelerRechts < vijandLinks ||
      spelerLinks > vijandRechts
    );
  }

  toon() {
    image(this.animatie[this.frameNummer], this.x, this.y, raster.celGrootte, raster.celGrootte);
    fill('black'); // Maak de levens tekst zwart
    textSize(20);
    text("Levens: " + this.leven, 10, 20); // Weergave van het aantal levens
  }
}
class Vijand {
  constructor(x, y, snelheid) {
    this.x = x;
    this.y = y;
    this.sprite = null;
    this.stapGrootte = null;
    this.snelheid = snelheid;
  }

  beweeg() {
    this.x += floor(random(-1, 2)) * this.stapGrootte;
    this.y += floor(random(-1, 2)) * this.stapGrootte;

    this.x = constrain(this.x, 0, canvas.width - raster.celGrootte);
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
  }

  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

class Bom {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.sprite = loadImage("images/sprites/bom.png");
    this.stapGrootte = null;
    this.beweegRichting = 1;
    this.snelheid = random(0.3, 0.6);
  }

  beweeg() {
    this.y += this.beweegRichting * this.stapGrootte * this.snelheid;

    if (this.y <= 0 || this.y >= canvas.height - raster.celGrootte) {
      this.beweegRichting *= -1;
    }
  }

  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

class Appel {
  constructor(x, y, sprite, beweegt) {
    this.x = x;
    this.y = y;
    this.sprite = loadImage(sprite);
    this.beweegt = beweegt;
    this.beweegRichtingX = random([-1, 1]);
    this.beweegRichtingY = random([-1, 1]);
    this.isVisible = true; // Voeg deze property toe
  }

  beweeg() {
    if (this.beweegt && this.isVisible) {
      this.x += this.beweegRichtingX * 2; // Pas snelheid aan
      this.y += this.beweegRichtingY * 2;

      if (this.x <= 0 || this.x >= canvas.width - raster.celGrootte) {
        this.beweegRichtingX *= -1; // Verander richting
      }
      if (this.y <= 0 || this.y >= canvas.height - raster.celGrootte) {
        this.beweegRichtingY *= -1; // Verander richting
      }
    }
  }

  toon() {
    if (this.isVisible) {
      image(this.sprite, this.x, this.y, raster.celGrootte - 10, raster.celGrootte - 10);
    }
  }

  isGeraakt(jos) {
    let marge = 10;
    if (!(jos.x + marge > this.x + raster.celGrootte - marge ||
        jos.x + raster.celGrootte - marge < this.x ||
        jos.y + marge > this.y + raster.celGrootte - marge ||
        jos.y + raster.celGrootte - marge < this.y)) {
      if (this.isVisible) { // Controleer of de appel zichtbaar is
        this.isVisible = false; // Maak de appel onzichtbaar
        return true; // Geef aan dat de appel is geraakt
      }
    }
    return false; // Geen aanrijding
  }
}

let rodeAppel;
let groeneAppel;

function preload() {
  brug = loadImage("images/backgrounds/dame_op_brug_1800.jpg");
}

function setup() {
  canvas = createCanvas(900, 600);
  canvas.parent();
  frameRate(10);
  textFont("Verdana");
  textSize(90);

  raster = new Raster(12, 18);
  raster.berekenCelGrootte();

  eve = new Jos();
  eve.stapGrootte = raster.celGrootte;

  for (var b = 0; b < 6; b++) {
    frameEve = loadImage("images/sprites/Eve100px/Eve_" + b + ".png");
    eve.animatie.push(frameEve);
  }

  alice = new Vijand(700, 200);
  alice.stapGrootte = eve.stapGrootte;
  alice.sprite = loadImage("images/sprites/Alice100px/Alice.png");

  bob = new Vijand(600, 400);
  bob.stapGrootte = eve.stapGrootte;
  bob.sprite = loadImage("images/sprites/Bob100px/Bob.png");

  // Voeg bommen toe, zorg ervoor dat ze niet in de onderste rij starten
  bommen = [];
  for (let i = 0; i < 5; i++) {
    let startX = floor(random(floor(raster.aantalKolommen / 2) + 1, raster.aantalKolommen)) * raster.celGrootte;
    let startY = floor(random(0, raster.aantalRijen - 1)) * raster.celGrootte; // Verander hier naar raster.aantalRijen - 1
    let bom = new Bom(startX, startY);
    bom.stapGrootte = raster.celGrootte;
    bommen.push(bom);
  }

  // Maak appelobjecten, zorg ervoor dat de groene appel niet in de onderste rij start
  groeneAppel = new Appel(
    floor(random(1, raster.aantalKolommen)) * raster.celGrootte,
    floor(random(0, raster.aantalRijen - 1)) * raster.celGrootte, // Verander hier naar raster.aantalRijen - 1
    "images/sprites/appel_1.png",
    true
  );

  rodeAppel = new Appel(
    floor(random(1, raster.aantalKolommen)) * raster.celGrootte,
    floor(random(0, raster.aantalRijen)) * raster.celGrootte, // Rode appel kan ook in de onderste rij zijn
    "images/sprites/appel_2.png",
    false
  );
}

function draw() {
  if (eve.leven > 0) {
    background(brug);
    raster.teken();

    // Beweeg en toon de karakters
    eve.beweeg();
    alice.beweeg();
    bob.beweeg();

    eve.toon();
    alice.toon();
    bob.toon();

    // Toon en beweeg de vijf bommen
    for (let i = bommen.length - 1; i >= 0; i--) {
      let bom = bommen[i];
      bom.beweeg();
      bom.toon();

      if (eve.wordtGeraakt(bom)) {
        // Reset Eve's positie naar de startpositie
        eve.x = eve.startX;
        eve.y = eve.startY;

        // Verwijder de bom van de lijst
        bommen.splice(i, 1);
        eve.leven--; // Verminder leven bij geraakt worden
      }
    }

    // Check of de speler geraakt wordt door Alice of Bob
    if (eve.wordtGeraakt(alice) || eve.wordtGeraakt(bob)) {
      // Reset Eve's positie naar de startpositie
      eve.x = eve.startX;
      eve.y = eve.startY;
      eve.leven--; // Verminder leven bij geraakt worden
    }

    // Beweeg en toon de appels
    rodeAppel.toon();
    groeneAppel.beweeg();
    groeneAppel.toon();

    // Controleer of de speler een groene appel heeft gegeten
    if (groeneAppel.isGeraakt(eve)) {
      eve.leven++; // Voeg een leven toe als de speler de groene appel eet
      groeneAppel.x = floor(random(1, raster.aantalKolommen)) * raster.celGrootte; // Verplaats de groene appel
      groeneAppel.y = floor(random(0, raster.aantalRijen - 1)) * raster.celGrootte; // Zorg dat het binnen het raster blijft
    }

    // Controleer of de speler een rode appel heeft gegeten
    if (rodeAppel.isGeraakt(eve)) {
      eve.leven++; // Voeg een leven toe als de speler de rode appel eet
      // Rode appel blijft op dezelfde plek, dus geen verplaatsing
    }

    // Check of de speler het einde heeft bereikt
    if (eve.gehaald) {
      background('green');
      fill('white');
      text("Je hebt gewonnen!", 30, 300);
      noLoop();
    }
  } else {
    // Als de speler geen levens meer heeft, geef dit aan
    background('red'); // Achtergrondkleur bij verlies
    fill('white');
    textSize(40);
    textAlign(CENTER);
    text("Game Over", canvas.width / 2, canvas.height / 2);
    textSize(20);
    text("Druk op F5 om opnieuw te starten", canvas.width / 2, canvas.height / 2 + 50);
    
    // Zorg ervoor dat de draw loop niet verder gaat
    noLoop(); // Stop de draw loop
  }
}
