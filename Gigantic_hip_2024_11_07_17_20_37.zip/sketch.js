let brug; // Achtergrondplaatje van een brug
let citySkyline; // Achtergrondplaatje van een skyline
let canvas; // Het speelveld waarop we tekenen
let raster; // Raster van vakjes om het spel overzichtelijk te maken
let eve; // Hoofdpersonage dat door de speler wordt bestuurd
let alice, bob; // Vijanden die door het spel bewegen
let bommen = []; // Een lijst om alle bommen op te slaan
let groeneAppel, rodeAppel; // Twee appels 

class Raster {
  // Constructor om het raster te initialiseren met rijen en kolommen
  constructor(r, k) {
    // Aantal rijen in het raster
    this.aantalRijen = r;
    // Aantal kolommen in het raster
    this.aantalKolommen = k;
    // Grootte van elke cel, nog te berekenen
    this.celGrootte = null;
  }

  // Methode om de grootte van elke cel in het raster te berekenen
  berekenCelGrootte() {
    // Verdeel de breedte van het canvas door het aantal kolommen om de celgrootte te bepalen
    this.celGrootte = canvas.width / this.aantalKolommen;
  }

teken() {
  // Begin een nieuwe grafische stijl
  push();
  // Zet de vulkleur uit en stel de lijnkleur in op grijs
  noFill();
  stroke('grey');

  // Loop door elke rij van het raster
  for (var rij = 0; rij < this.aantalRijen; rij++) {
    // Loop door elke kolom van het raster
    for (var kolom = 0; kolom < this.aantalKolommen; kolom++) {
      // Controleer of we in rij 5 of kolom 7 zijn
      if (rij === 5 || kolom === 7) {
        fill('orange'); // Stel de kleur in op oranje voor cellen in rij 5 of kolom 7
      } else {
        noFill(); // Geen vulkleur voor andere cellen
      }
      // Teken een rechthoek voor elke cel in het raster
      rect(kolom * this.celGrootte, rij * this.celGrootte, this.celGrootte, this.celGrootte);
      noFill(); // Reset de vulkleur naar geen vulkleur na het tekenen van de cel
    }
  }

  // Herstel de vorige grafische stijlinstellingen
  pop();
}

}

class Jos {
  constructor() {
    this.x = 400; // Startpositie op de breedte-as
    this.y = 300; // Startpositie op de hoogte-as
    this.animatie = []; // Array om de animatie frames van Jos op te slaan
    this.frameNummer = 3; // Het initiële frame voor animatie
    this.stapGrootte = null; // De grootte van de stap die Jos per beweging maakt
    this.gehaald = false; // Of Jos de finish heeft bereikt
    this.leven = 1; // Aantal levens waarmee Jos start
    this.startX = this.x; // Opslaan van de startpositie op de breedte-as
    this.startY = this.y; // Opslaan van de startpositie op de hoogte-as
  }
  
  beweeg() {
    if (keyIsDown(65)) {  //Als A toets wordt ingedrukt
      this.x -= this.stapGrootte; // Naar links
      this.frameNummer = 2;
    }
    if (keyIsDown(68)) { //Als D toets wordt ingedrukt
      this.x += this.stapGrootte; // Naar rechts
      this.frameNummer = 1;
    }
    if (keyIsDown(87)) { //Als W toets wordt ingedrukt
      this.y -= this.stapGrootte; //Omhoog
      this.frameNummer = 4;
    }
    if (keyIsDown(83)) { //Als S toets wordt ingedrukt
      this.y += this.stapGrootte; //Omlaag
      this.frameNummer = 5;
    }
this.x = constrain(this.x, 0, canvas.width); // Beperk de x-positie van Jos tot de breedte van het canvas
this.y = constrain(this.y, 0, canvas.height - raster.celGrootte); // Beperk de y-positie van Jos tot de hoogte van het canvas minus de grootte van één rastercel

if (this.x == canvas.width) { // Controleer of Jos de rechterrand van het canvas heeft bereikt
  this.gehaald = true; // Markeer dat Jos het doel heeft bereikt
}

// Methode om te controleren of Jos wordt geraakt door een vijand
      this.x = constrain(this.x, 0, canvas.width); // Beperk de x-positie van Jos tot de breedte van het canvas
      this.y = constrain(this.y, 0, canvas.height - raster.celGrootte); // Beperk de y-positie van Jos tot de hoogte van het canvas minus de grootte van één rastercel
    if (this.x == canvas.width) {
      this.gehaald = true;
    }
  }

  wordtGeraakt(vijand) {
    let marge = 10;

     // Bereken de grenzen van Jos met de marge
  let spelerLinks = this.x + marge; // Linkergrens van Jos
  let spelerRechts = this.x + raster.celGrootte - marge; // Rechtergrens van Jos
  let spelerBoven = this.y + marge; // Bovengrens van Jos
  let spelerOnder = this.y + raster.celGrootte - marge; // Ondergrens van Jos

    // Bereken de grenzen van de vijand met de marge
  let vijandLinks = vijand.x + marge; // Linkergrens van de vijand
  let vijandRechts = vijand.x + raster.celGrootte - marge; // Rechtergrens van de vijand
  let vijandBoven = vijand.y + marge; // Bovengrens van de vijand
  let vijandOnder = vijand.y + raster.celGrootte - marge; // Ondergrens van de vijand
    
  // Controleer of de grenzen van Jos en de vijand elkaar overlappen, wat wijst op een botsing
  return !(
    spelerOnder < vijandBoven || // Geen botsing als Jos onder de vijand is
    spelerBoven > vijandOnder || // Geen botsing als Jos boven de vijand is
    spelerRechts < vijandLinks || // Geen botsing als Jos links van de vijand is
    spelerLinks > vijandRechts // Geen botsing als Jos rechts van de vijand is 
  );
  }  

  toon() {
    image(this.animatie[this.frameNummer], this.x, this.y, raster.celGrootte, raster.celGrootte);
    fill('black'); // Maak de levens tekst zwart
    textSize(20);
    text("Levens: " + this.leven, 10, 20); // Weergave van het aantal levens
  }
}

class Vijand {
  // Constructor om de vijand te initialiseren
  constructor(x, y, snelheid) {
    // Coördinaten van de vijand op het canvas
    this.x = x;
    this.y = y;
    // Sprite voor de weergave van de vijand (nog in te stellen)
    this.sprite = null;
    // Stapgrootte bepaalt de hoeveelheid beweging bij elke stap (nog in te stellen)
    this.stapGrootte = null;
    // Snelheid van de vijand (wordt ingesteld bij aanroepen van de constructor)
    this.snelheid = snelheid;
  }

  // Methode om de vijand willekeurig te verplaatsen op het canvas
  beweeg() {
    // Bepaalt een willekeurige beweging in de x- en y-richting
    this.x += floor(random(-1, 2)) * this.stapGrootte;
    this.y += floor(random(-1, 2)) * this.stapGrootte;

    // Beperk de x- en y-coördinaten binnen de canvasgrenzen, zodat de vijand op het scherm blijft
    this.x = constrain(this.x, 0, canvas.width - raster.celGrootte);
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
  }

  // Methode om de vijand weer te geven op het canvas
  toon() {
    // Toont het sprite-afbeelding van de vijand op de huidige x- en y-coördinaten
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}


class Bom {
  // Constructor om een bom te initialiseren
  constructor(x, y) {
    // Coördinaten van de bom op het canvas
    this.x = x;
    this.y = y;
    // Laad het sprite-afbeelding voor de bom
    this.sprite = loadImage("images/sprites/bom.png");
    // Stapgrootte bepaalt de afstand die de bom per stap beweegt (nog in te stellen)
    this.stapGrootte = null;
    // Richting waarin de bom beweegt (1 voor omlaag, -1 voor omhoog)
    this.beweegRichting = 1;
    // Willekeurige snelheid van de bom binnen het bereik 0.3 tot 0.6
    this.snelheid = random(0.3, 0.6);
  }

  // Methode om de bom verticaal te verplaatsen
  beweeg() {
    // Verplaats de bom in de y-richting op basis van stapgrootte, snelheid en richting
    this.y += this.beweegRichting * this.stapGrootte * this.snelheid;

    // Controleer of de bom de boven- of onderkant van het canvas raakt
    if (this.y <= 0 || this.y >= canvas.height - raster.celGrootte) {
      // Keer de bewegingsrichting om als de bom een grens bereikt
      this.beweegRichting *= -1;
    }
  }

  // Methode om de bom op het canvas weer te geven
  toon() {
    // Toon het sprite-afbeelding van de bom op de huidige x- en y-coördinaten
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

class Appel {
  // Constructor om een appel te initialiseren
  constructor(x, y, sprite, beweegt) {
    // Coördinaten van de appel op het canvas
    this.x = x;
    this.y = y;
    // Laad het sprite-afbeelding voor de appel
    this.sprite = loadImage(sprite);
    // Bepaalt of de appel kan bewegen
    this.beweegt = beweegt;
    // Willekeurige bewegingsrichting voor x en y (kan -1 of 1 zijn)
    this.beweegRichtingX = random([-1, 1]);
    this.beweegRichtingY = random([-1, 1]);
    // Eigenschap om te bepalen of de appel zichtbaar is
    this.isVisible = true;
  }

  // Methode om de appel te verplaatsen
  beweeg() {
    // Controleer of de appel beweegt en zichtbaar is
    if (this.beweegt && this.isVisible) {
      // Verplaats de appel in x- en y-richting
      this.x += this.beweegRichtingX * 2; // Snelheid aanpassen
      this.y += this.beweegRichtingY * 2;

      // Controleer of de appel buiten de canvasgrenzen komt in de x-richting
      if (this.x <= 0 || this.x >= canvas.width - raster.celGrootte) {
        this.beweegRichtingX *= -1; // Verander x-richting
      }
      // Controleer of de appel buiten de canvasgrenzen komt in de y-richting
      if (this.y <= 0 || this.y >= canvas.height - raster.celGrootte) {
        this.beweegRichtingY *= -1; // Verander y-richting
      }
    }
  }

  // Methode om de appel weer te geven op het canvas
  toon() {
    if (this.isVisible) {
      // Toon het sprite-afbeelding van de appel op de huidige positie met aangepaste grootte
      image(this.sprite, this.x, this.y, raster.celGrootte - 10, raster.celGrootte - 10);
    }
  }

  // Methode om te controleren of de appel is geraakt door een object (bijv. speler)
  isGeraakt(jos) {
    // Marges om de nauwkeurigheid van de aanrijding te verfijnen
    let marge = 10;
    // Controleer op overlapping tussen de appel en het object `jos`
    if (!(jos.x + marge > this.x + raster.celGrootte - marge ||
          jos.x + raster.celGrootte - marge < this.x ||
          jos.y + marge > this.y + raster.celGrootte - marge ||
          jos.y + raster.celGrootte - marge < this.y)) {
      // Controleer of de appel zichtbaar is voordat hij onzichtbaar wordt gemaakt
      if (this.isVisible) {
        this.isVisible = false; // Maak de appel onzichtbaar
        return true; // Geef aan dat de appel is geraakt
      }
    }
    return false; // Geen aanrijding gedetecteerd
  }
}

let isOverOranje = false; // Voeg een variabele toe om bij te houden of de muis over een oranje cel is

function preload() {
  brug = loadImage("images/backgrounds/dame_op_brug_1800.jpg");
  citySkyline = loadImage("images/backgrounds/city_skyline.png"); // Voeg de skyline afbeelding toe
}

function setup() {
  // Maak een canvas van 900x600 pixels en voeg het toe aan de HTML-pagina
  canvas = createCanvas(900, 600);
  canvas.parent();
  // Stel de framesnelheid in op 10 frames per seconde
  frameRate(10);
  // Gebruik het lettertype Verdana en stel de tekstgrootte in op 90
  textFont("Verdana");
  textSize(90);

  // Maak een raster met 12 rijen en 18 kolommen en bereken de celgrootte
  raster = new Raster(12, 18);
  raster.berekenCelGrootte();

  // Maak een spelerobject (eve) en stel de stapgrootte in op de rastercelgrootte
  eve = new Jos();
  eve.stapGrootte = raster.celGrootte;

  // Laad de frames voor de animatie van de speler (eve) en voeg deze toe aan het animatie-array
  for (var b = 0; b < 6; b++) {
    frameEve = loadImage("images/sprites/Eve100px/Eve_" + b + ".png");
    eve.animatie.push(frameEve);
  }

  // Maak een vijand (alice) en stel haar stapgrootte en sprite in
  alice = new Vijand(700, 200);
  alice.stapGrootte = eve.stapGrootte;
  alice.sprite = loadImage("images/sprites/Alice100px/Alice.png");

  // Maak een andere vijand (bob) en stel zijn stapgrootte en sprite in
  bob = new Vijand(600, 400);
  bob.stapGrootte = eve.stapGrootte;
  bob.sprite = loadImage("images/sprites/Bob100px/Bob.png");

  // Voeg bommen toe aan het spel, zorg ervoor dat ze niet in de onderste rij starten
  bommen = [];
  for (let i = 0; i < 5; i++) {
    // Kies een startpositie voor de bommen, links van het rastermidden en niet in de onderste rij
    let startX = floor(random(floor(raster.aantalKolommen / 2) + 1, raster.aantalKolommen)) * raster.celGrootte;
    let startY = floor(random(0, raster.aantalRijen - 1)) * raster.celGrootte; // Geen bommen in de onderste rij
    // Maak een bomobject en stel de stapgrootte in op de rastercelgrootte
    let bom = new Bom(startX, startY);
    bom.stapGrootte = raster.celGrootte;
    bommen.push(bom);
  }

  // Maak een groene appel die kan bewegen, zorg dat deze niet in de onderste rij start
  groeneAppel = new Appel(
    floor(random(1, raster.aantalKolommen)) * raster.celGrootte,
    floor(random(0, raster.aantalRijen - 1)) * raster.celGrootte, // Geen groene appel in de onderste rij
    "images/sprites/appel_1.png",
    true // Groene appel kan bewegen
  );

  // Maak een rode appel die niet beweegt, deze kan wel in de onderste rij starten
  rodeAppel = new Appel(
    floor(random(1, raster.aantalKolommen)) * raster.celGrootte,
    floor(random(0, raster.aantalRijen)) * raster.celGrootte, // Rode appel kan overal, ook in de onderste rij
    "images/sprites/appel_2.png",
    false // Rode appel is statisch
  );
}

function draw() {
  // Wijzig de achtergrond op basis van of de muis over een oranje cel is
  if (isOverOranje) {
    background(citySkyline); // Toon de skyline als de muis boven een oranje cel is
  } else {
    background(brug);
  }

  if (eve.leven > 0) {
    raster.teken();

    // Beweeg en toon de karakters
    eve.beweeg();
    alice.beweeg();
    bob.beweeg();

    eve.toon();
    alice.toon();
    bob.toon();

    // Toon en beweeg de vijf bommen
    for (let i = bommen.length - 1; i >= 0; i--) {
      let bom = bommen[i];
      bom.beweeg();
      bom.toon();

      if (eve.wordtGeraakt(bom)) {
        // Reset Eve's positie naar de startpositie
        eve.x = eve.startX;
        eve.y = eve.startY;

        // Verwijder de bom van de lijst
        bommen.splice(i, 1);
        eve.leven--; // Verminder leven bij geraakt worden
      }
    }

    // Check of de speler geraakt wordt door Alice of Bob
    if (eve.wordtGeraakt(alice) || eve.wordtGeraakt(bob)) {
      // Reset Eve's positie naar de startpositie
      eve.x = eve.startX;
      eve.y = eve.startY;
      eve.leven--; // Verminder leven bij geraakt worden
    }

    // Beweeg en toon de appels
    rodeAppel.toon();
    groeneAppel.beweeg();
    groeneAppel.toon();

    // Controleer of de speler een groene appel heeft gegeten
    if (groeneAppel.isGeraakt(eve)) {
      eve.leven++; // Voeg een leven toe als de speler de groene appel eet
      groeneAppel.x = floor(random(1, raster.aantalKolommen)) * raster.celGrootte; // Verplaats de groene appel
      groeneAppel.y = floor(random(0, raster.aantalRijen - 1)) * raster.celGrootte; // Zorg dat het binnen het raster blijft
    }

    // Controleer of de speler een rode appel heeft gegeten
    if (rodeAppel.isGeraakt(eve)) {
      eve.leven++; // Voeg een leven toe als de speler de rode appel eet
      // Rode appel blijft op dezelfde plek, dus geen verplaatsing
    }

    // Check of de speler het einde heeft bereikt
    if (eve.gehaald) {
      background('green'); // Achtergrond wordt groen
      fill('white'); // tekst kleur is wit
      textSize(40); // Grootte van de tekst
      text("Je hebt gewonnen!", 300, 300); // Tekst en de positie van de tekst
      noLoop(); // Stopt de loop
    }
  } else {
    // Als de speler geen levens meer heeft, geef dit aan
    background('red'); // Achtergrondkleur bij verlies
    fill('white'); 
    textSize(40);
    text("Game Over", canvas.width / 2, canvas.height / 2);
    textSize(20);
    text("Druk op F5 om opnieuw te starten", canvas.width / 2, canvas.height / 2 + 50);
    
    // Zorg ervoor dat de draw loop niet verder gaat
    noLoop(); // Stop de draw loop
  }
}

function mouseMoved() {
  if (!raster || !raster.celGrootte) {
    return; // Stop de functie als raster of celGrootte niet beschikbaar is
  }
  
  let kolom = floor(mouseX / raster.celGrootte);
  let rij = floor(mouseY / raster.celGrootte);
  
  // Controleer of de muis zich in rij 5 of kolom 7 bevindt
  if (rij === 5 || kolom === 7) {
    isOverOranje = true; // Stel de vlag in dat de muis boven een oranje cel is
  } else {
    isOverOranje = false; // Reset de vlag
  }
}

